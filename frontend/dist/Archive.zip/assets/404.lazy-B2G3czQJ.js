import{c as o,N as r}from"./index-BHE236ec.js";const t=o("/(errors)/404")({component:r});export{t as Route};
