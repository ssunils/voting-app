import{c as r,G as e}from"./index-BHE236ec.js";const t=r("/(errors)/500")({component:e});export{t as Route};
