import{c as r,G as e}from"./index-Cs80-uD8.js";const t=r("/(errors)/500")({component:e});export{t as Route};
