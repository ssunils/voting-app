import{c as o,N as r}from"./index-Cs80-uD8.js";const t=o("/(errors)/404")({component:r});export{t as Route};
